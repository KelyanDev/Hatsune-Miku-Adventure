vertical_tile_number = 10
tile_size = 48

screen_width = 800
screen_height = vertical_tile_number * tile_size