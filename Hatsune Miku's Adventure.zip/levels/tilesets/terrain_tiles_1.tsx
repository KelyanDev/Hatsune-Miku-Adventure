<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="terrain_tiles" tilewidth="48" tileheight="48" tilecount="100" columns="10">
 <image source="../../graphics/terrain/terrain_tiles.png" width="480" height="480"/>
</tileset>
