<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="setup_tiles" tilewidth="48" tileheight="48" tilecount="2" columns="2">
 <image source="../../graphics/character/setup_tiles.png" width="96" height="48"/>
</tileset>
