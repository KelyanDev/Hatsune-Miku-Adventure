<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="decorations" tilewidth="85" tileheight="96" tilecount="58" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="85" height="28" source="../../graphics/decoration/Car.png"/>
 </tile>
 <tile id="1">
  <image width="18" height="22" source="../../graphics/decoration/Barrel1.png"/>
 </tile>
 <tile id="2">
  <image width="18" height="33" source="../../graphics/decoration/Barrel2.png"/>
 </tile>
 <tile id="3">
  <image width="27" height="18" source="../../graphics/decoration/Barrel3.png"/>
 </tile>
 <tile id="4">
  <image width="32" height="28" source="../../graphics/decoration/Box1.png"/>
 </tile>
 <tile id="5">
  <image width="26" height="20" source="../../graphics/decoration/Box2.png"/>
 </tile>
 <tile id="6">
  <image width="26" height="19" source="../../graphics/decoration/Box3.png"/>
 </tile>
 <tile id="7">
  <image width="26" height="14" source="../../graphics/decoration/Box4.png"/>
 </tile>
 <tile id="8">
  <image width="20" height="16" source="../../graphics/decoration/Box5.png"/>
 </tile>
 <tile id="9">
  <image width="20" height="14" source="../../graphics/decoration/Box6.png"/>
 </tile>
 <tile id="10">
  <image width="20" height="14" source="../../graphics/decoration/Box7.png"/>
 </tile>
 <tile id="11">
  <image width="20" height="10" source="../../graphics/decoration/Box8.png"/>
 </tile>
 <tile id="12">
  <image width="18" height="13" source="../../graphics/decoration/Box9.png"/>
 </tile>
 <tile id="13">
  <image width="16" height="10" source="../../graphics/decoration/Box10.png"/>
 </tile>
 <tile id="14">
  <image width="16" height="9" source="../../graphics/decoration/Box11.png"/>
 </tile>
 <tile id="15">
  <image width="16" height="5" source="../../graphics/decoration/Box12.png"/>
 </tile>
 <tile id="16">
  <image width="39" height="28" source="../../graphics/decoration/trash_can2.png"/>
 </tile>
 <tile id="17">
  <image width="21" height="18" source="../../graphics/decoration/trash_can3.png"/>
 </tile>
 <tile id="18">
  <image width="64" height="28" source="../../graphics/decoration/trash_can4.png"/>
 </tile>
 <tile id="19">
  <image width="39" height="28" source="../../graphics/decoration/trash_can5.png"/>
 </tile>
 <tile id="20">
  <image width="21" height="18" source="../../graphics/decoration/trash_can6.png"/>
 </tile>
 <tile id="21">
  <image width="42" height="11" source="../../graphics/decoration/Chest1.png"/>
 </tile>
 <tile id="22">
  <image width="32" height="16" source="../../graphics/decoration/Chest2.png"/>
 </tile>
 <tile id="23">
  <image width="42" height="22" source="../../graphics/decoration/Chest3.png"/>
 </tile>
 <tile id="24">
  <image width="56" height="17" source="../../graphics/decoration/Chest5.png"/>
 </tile>
 <tile id="25">
  <image width="29" height="17" source="../../graphics/decoration/Conditioner1.png"/>
 </tile>
 <tile id="26">
  <image width="27" height="17" source="../../graphics/decoration/Conditioner2.png"/>
 </tile>
 <tile id="27">
  <image width="26" height="17" source="../../graphics/decoration/Conditioner3.png"/>
 </tile>
 <tile id="28">
  <image width="25" height="96" source="../../graphics/decoration/Flashlight1.png"/>
 </tile>
 <tile id="29">
  <image width="19" height="96" source="../../graphics/decoration/Flashlight2.png"/>
 </tile>
 <tile id="30">
  <image width="24" height="96" source="../../graphics/decoration/Flashlight3.png"/>
 </tile>
 <tile id="31">
  <image width="15" height="65" source="../../graphics/decoration/Flashlight4.png"/>
 </tile>
 <tile id="32">
  <image width="15" height="5" source="../../graphics/decoration/Garbage1.png"/>
 </tile>
 <tile id="33">
  <image width="11" height="14" source="../../graphics/decoration/Garbage2.png"/>
 </tile>
 <tile id="34">
  <image width="16" height="13" source="../../graphics/decoration/Garbage3.png"/>
 </tile>
 <tile id="35">
  <image width="27" height="16" source="../../graphics/decoration/Garbage4.png"/>
 </tile>
 <tile id="36">
  <image width="27" height="20" source="../../graphics/decoration/Garbage5.png"/>
 </tile>
 <tile id="37">
  <image width="24" height="20" source="../../graphics/decoration/Garbage6.png"/>
 </tile>
 <tile id="38">
  <image width="11" height="19" source="../../graphics/decoration/Garbage7.png"/>
 </tile>
 <tile id="39">
  <image width="15" height="15" source="../../graphics/decoration/Garbage8.png"/>
 </tile>
 <tile id="40">
  <image width="16" height="8" source="../../graphics/decoration/Garbage9.png"/>
 </tile>
 <tile id="41">
  <image width="18" height="19" source="../../graphics/decoration/Garbage10.png"/>
 </tile>
 <tile id="42">
  <image width="17" height="22" source="../../graphics/decoration/Garbage11.png"/>
 </tile>
 <tile id="43">
  <image width="3" height="2" source="../../graphics/decoration/Grass1.png"/>
 </tile>
 <tile id="44">
  <image width="4" height="4" source="../../graphics/decoration/Grass2.png"/>
 </tile>
 <tile id="45">
  <image width="7" height="5" source="../../graphics/decoration/Grass3.png"/>
 </tile>
 <tile id="46">
  <image width="5" height="3" source="../../graphics/decoration/Grass4.png"/>
 </tile>
 <tile id="47">
  <image width="5" height="4" source="../../graphics/decoration/Grass5.png"/>
 </tile>
 <tile id="48">
  <image width="5" height="6" source="../../graphics/decoration/Grass6.png"/>
 </tile>
 <tile id="49">
  <image width="9" height="9" source="../../graphics/decoration/Grass7.png"/>
 </tile>
 <tile id="50">
  <image width="9" height="11" source="../../graphics/decoration/Grass8.png"/>
 </tile>
 <tile id="51">
  <image width="13" height="9" source="../../graphics/decoration/Grass9.png"/>
 </tile>
 <tile id="52">
  <image width="11" height="9" source="../../graphics/decoration/Grass10.png"/>
 </tile>
 <tile id="53">
  <image width="16" height="16" source="../../graphics/decoration/Traffic_cone1.png"/>
 </tile>
 <tile id="54">
  <image width="14" height="16" source="../../graphics/decoration/Traffic_cone2.png"/>
 </tile>
 <tile id="55">
  <image width="12" height="16" source="../../graphics/decoration/Traffic_cone3.png"/>
 </tile>
 <tile id="56">
  <image width="14" height="22" source="../../graphics/decoration/Traffic_cone4.png"/>
 </tile>
 <tile id="57">
  <image width="63" height="28" source="../../graphics/decoration/trash_can1.png"/>
 </tile>
</tileset>
